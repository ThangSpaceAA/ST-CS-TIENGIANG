/*****************************************************************************
* | File      	:   Readme.txt
* | Author      :   Waveshare team
* | Function    :   Help with use
* | Info        :
*----------------
* |	This version:   V1.0
* | Date        :   2021-09-07
* | Info        :   
******************************************************************************/
All operation steps reference: 

	CN:  https://www.waveshare.net/wiki/Compute_Module_4_PoE_4G_Board
	
	EN:  https://www.waveshare.com/wiki/Compute_Module_4_PoE_4G_Board